// �����Ϳ������á������ࡱ�����ļ�������ɵ� IDispatch ��װ��

//#import "C:\\Program Files\\Adobe\\Adobe Photoshop CS6 (64 Bit)\\Required\\Plug-Ins\\Extensions\\ScriptingSupport.8li" no_namespace
// CArtLayers ��װ��

class CArtLayers : public COleDispatchDriver
{
public:
	CArtLayers(){} // ���� COleDispatchDriver Ĭ�Ϲ��캯��
	CArtLayers(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CArtLayers(const CArtLayers& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// ����
public:

	// ����
public:


	// ArtLayers ����
public:
	LPDISPATCH get_Application()
	{
		LPDISPATCH result;
		InvokeHelper(0x63617070, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
		return result;
	}
	LPDISPATCH get_Parent()
	{
		LPDISPATCH result;
		InvokeHelper(0x63746e72, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, NULL);
		return result;
	}
	long get_Count()
	{
		long result;
		InvokeHelper(0x636e7465, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	LPUNKNOWN get__NewEnum()
	{
		LPUNKNOWN result;
		InvokeHelper(0xfffffffc, DISPATCH_PROPERTYGET, VT_UNKNOWN, (void*)&result, NULL);
		return result;
	}
	void Remove(LPDISPATCH Item)
	{
		static BYTE parms[] = VTS_DISPATCH ;
		InvokeHelper(0x64656c6f, DISPATCH_METHOD, VT_EMPTY, NULL, parms, Item);
	}
	void RemoveAll()
	{
		InvokeHelper(0x5241456c, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	LPDISPATCH get_Item(VARIANT& ItemKey)
	{
		LPDISPATCH result;
		static BYTE parms[] = VTS_VARIANT ;
		InvokeHelper(0x0, DISPATCH_PROPERTYGET, VT_DISPATCH, (void*)&result, parms, &ItemKey);
		return result;
	}
	long Index(LPDISPATCH ItemPtr)
	{
		long result;
		static BYTE parms[] = VTS_DISPATCH ;
		InvokeHelper(0x70696478, DISPATCH_METHOD, VT_I4, (void*)&result, parms, ItemPtr);
		return result;
	}
	LPDISPATCH Add()
	{
		LPDISPATCH result;
		InvokeHelper(0x63434c6a, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, NULL);
		return result;
	}

	// ArtLayers ����
public:

};
