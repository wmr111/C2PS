// �����Ϳ������á������ࡱ�����ļ�������ɵ� IDispatch ��װ��

//#import "C:\\Program Files (x86)\\Adobe\\Acrobat DC\\Acrobat\\acrobat.tlb" no_namespace
// CCAcroPDDoc ��װ��

class CCAcroPDDoc : public COleDispatchDriver
{
public:
	CCAcroPDDoc(){} // ���� COleDispatchDriver Ĭ�Ϲ��캯��
	CCAcroPDDoc(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CCAcroPDDoc(const CCAcroPDDoc& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// ����
public:

	// ����
public:


	// CAcroPDDoc ����
public:
	BOOL Open(LPCTSTR szFullPath)
	{
		BOOL result;
		static BYTE parms[] = VTS_BSTR ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, szFullPath);
		return result;
	}
	BOOL Close()
	{
		BOOL result;
		InvokeHelper(0x2, DISPATCH_METHOD, VT_BOOL, (void*)&result, NULL);
		return result;
	}
	BOOL InsertPages(long nInsertPageAfter, LPDISPATCH iPDDocSource, long lStartPage, long lNumPages, long lInsertFlags)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 VTS_DISPATCH VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x3, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, nInsertPageAfter, iPDDocSource, lStartPage, lNumPages, lInsertFlags);
		return result;
	}
	BOOL ReplacePages(long nStartPage, LPDISPATCH iPDDocSource, long lStartSourcePage, long lNumPages, long bMergeTextAnnotations)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 VTS_DISPATCH VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x4, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, nStartPage, iPDDocSource, lStartSourcePage, lNumPages, bMergeTextAnnotations);
		return result;
	}
	BOOL DeletePages(long nStartPage, long nEndPage)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0x5, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, nStartPage, nEndPage);
		return result;
	}
	long GetNumPages()
	{
		long result;
		InvokeHelper(0x6, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
		return result;
	}
	BOOL Create()
	{
		BOOL result;
		InvokeHelper(0x7, DISPATCH_METHOD, VT_BOOL, (void*)&result, NULL);
		return result;
	}
	CString GetInfo(LPCTSTR sInfoKey)
	{
		CString result;
		static BYTE parms[] = VTS_BSTR ;
		InvokeHelper(0x8, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms, sInfoKey);
		return result;
	}
	BOOL SetInfo(LPCTSTR sInfoKey, LPCTSTR szBuffer)
	{
		BOOL result;
		static BYTE parms[] = VTS_BSTR VTS_BSTR ;
		InvokeHelper(0x9, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, sInfoKey, szBuffer);
		return result;
	}
	BOOL DeleteThumbs(long lStartPage, long lEndPage)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0xa, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, lStartPage, lEndPage);
		return result;
	}
	BOOL MovePage(long lMoveAfterThisPage, long lPageToMove)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0xb, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, lMoveAfterThisPage, lPageToMove);
		return result;
	}
	CString GetFileName()
	{
		CString result;
		InvokeHelper(0xc, DISPATCH_METHOD, VT_BSTR, (void*)&result, NULL);
		return result;
	}
	long GetPageMode()
	{
		long result;
		InvokeHelper(0xd, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
		return result;
	}
	BOOL SetPageMode(long nPageMode)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0xe, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, nPageMode);
		return result;
	}
	BOOL CreateThumbs(long lFirstPage, long lLastPage)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0xf, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, lFirstPage, lLastPage);
		return result;
	}
	LPDISPATCH CreateTextSelect(long lPage, LPDISPATCH iAcroRect)
	{
		LPDISPATCH result;
		static BYTE parms[] = VTS_I4 VTS_DISPATCH ;
		InvokeHelper(0x10, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, parms, lPage, iAcroRect);
		return result;
	}
	LPDISPATCH AcquirePage(long nPage)
	{
		LPDISPATCH result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x11, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, parms, nPage);
		return result;
	}
	CString GetInstanceID()
	{
		CString result;
		InvokeHelper(0x12, DISPATCH_METHOD, VT_BSTR, (void*)&result, NULL);
		return result;
	}
	CString GetPermanentID()
	{
		CString result;
		InvokeHelper(0x13, DISPATCH_METHOD, VT_BSTR, (void*)&result, NULL);
		return result;
	}
	long GetFlags()
	{
		long result;
		InvokeHelper(0x14, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
		return result;
	}
	BOOL SetFlags(long nFlags)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x15, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, nFlags);
		return result;
	}
	LPDISPATCH OpenAVDoc(LPCTSTR sTempTitle)
	{
		LPDISPATCH result;
		static BYTE parms[] = VTS_BSTR ;
		InvokeHelper(0x16, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, parms, sTempTitle);
		return result;
	}
	BOOL Save(short nType, LPCTSTR sFullPath)
	{
		BOOL result;
		static BYTE parms[] = VTS_I2 VTS_BSTR ;
		InvokeHelper(0x17, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, nType, sFullPath);
		return result;
	}
	BOOL ClearFlags(long nFlags)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x18, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, nFlags);
		return result;
	}
	BOOL SetOpenInfo(long pgNum, short viewMode, LPCTSTR magnification)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 VTS_I2 VTS_BSTR ;
		InvokeHelper(0x19, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, pgNum, viewMode, magnification);
		return result;
	}
	BOOL CropPages(long nStartPage, long nEndPage, short nOddOrEvenPagesOnly, LPDISPATCH iAcroRect)
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I2 VTS_DISPATCH ;
		InvokeHelper(0x1a, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, nStartPage, nEndPage, nOddOrEvenPagesOnly, iAcroRect);
		return result;
	}
	LPDISPATCH GetJSObject()
	{
		LPDISPATCH result;
		InvokeHelper(0x1b, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, NULL);
		return result;
	}

	// CAcroPDDoc ����
public:

};
