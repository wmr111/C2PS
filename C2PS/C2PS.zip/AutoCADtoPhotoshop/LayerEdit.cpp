// (C) Copyright 2002-2007 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

//-----------------------------------------------------------------------------
//----- LayerEdit.cpp : Implementation of CLayerEdit
//-----------------------------------------------------------------------------
#include "StdAfx.h"
#include "resource.h"
#include "LayerEdit.h"

//-----------------------------------------------------------------------------
IMPLEMENT_DYNAMIC (CLayerEdit, CAcUiEdit)

BEGIN_MESSAGE_MAP(CLayerEdit, CAcUiEdit)
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_CREATE()
	ON_WM_KILLFOCUS()
	ON_WM_CHAR()
	ON_WM_MOUSEWHEEL()
END_MESSAGE_MAP()

//-----------------------------------------------------------------------------
CLayerEdit::CLayerEdit () {
}

//-----------------------------------------------------------------------------
CLayerEdit::~CLayerEdit () {
}
HBRUSH CLayerEdit::CtlColor(CDC* pDC, UINT /*nCtlColor*/)
{
	pDC->SetBkMode(TRANSPARENT);
	return m_Brush;
}


int CLayerEdit::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CEdit::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_Brush.CreateSolidBrush(RGB(191, 191, 255));
	m_bDone = TRUE;
	return 0;
}


void CLayerEdit::OnKillFocus(CWnd* pNewWnd)
{
	CEdit::OnKillFocus(pNewWnd);
	ShowWindow(SW_HIDE);
	if (m_bDone)
	{
		CString rStr;
		GetWindowText(rStr);
		GetParent()->SendMessage(WM_EDITDONE, 0, (LPARAM)rStr.GetBuffer());
	}
	else
	{
		m_bDone = TRUE;
		GetParent()->SendMessage(WM_EDITCANCEL, 0, 0);
	}
}


void CLayerEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar=='\r')
	{
		GetParent()->SetFocus();
		return;
	}
	else if (nChar=='\x1b')
	{
		m_bDone = FALSE;
		GetParent()->SetFocus();
		return;
	}
	CAcUiEdit::OnChar(nChar, nRepCnt, nFlags);
}


BOOL CLayerEdit::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	GetParent()->SetFocus();
	return CAcUiEdit::OnMouseWheel(nFlags, zDelta, pt);
}
